export const products = [
    {
        id: 1,
        name: "Super Backpack",
        price: 129.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "public/images/productss/bag1.jpg"
    },
    {
        id: 2,
        name: "New Hip",
        price: 199.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "public/images/productss/bag2.jpg"
    },
    {
        id: 3,
        name: "Elite Series",
        price: 189.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "public/images/productss/bag3.jpg"
    },
    {
        id: 4,
        name: "Casual",
        price: 129.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "public/images/productss/bag4.jpg"
    },
    {
        id: 5,
        name: "Best Tote",
        price: 399.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "public/images/productss/bag5.jpg"
    },
    {
        id: 6,
        name: "Charming Series",
        price: 689.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "public/images/productss/bag6.jpg"
    },
    {
        id: 7,
        name: "Charming Series",
        price: 689.99,
        description: "Torem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmo tempor incididunt ut labore et dolore magna",
        image: "public/images/productss/bag7.jpg"
    }
]