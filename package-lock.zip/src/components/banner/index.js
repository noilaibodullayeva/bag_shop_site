import { useTheme } from "@mui/material/styles"
import { Typography, useMediaQuery } from "@mui/material"
import { BannerContainer, BannerContent, BannerDecs, BannerImage, BannerTitle } from "../../styles/banner";

const Banner = () => {
    const theme = useTheme();
    const matches = useMediaQuery(theme.breakpoints.down(`md`))

    return (


        <BannerContainer>
            <BannerImage src="https://prodimage.images-bn.com/lf?set=key%5Bresolve.pixelRatio%5D,value%5B1%5D&set=key%5Bresolve.width%5D,value%5B600%5D&set=key%5Bresolve.height%5D,value%5B10000%5D&set=key%5Bresolve.imageFit%5D,value%5Bcontainerwidth%5D&set=key%5Bresolve.allowImageUpscaling%5D,value%5B0%5D&set=key%5Bresolve.format%5D,value%5Bwebp%5D&source=url%5Bhttps://prodimage.images-bn.com/pimages/9780735363144_p0_v1_s600x595.jpg%5D&scale=options%5Blimit%5D,size%5B600x10000%5D&sink=format%5Bwebp%5D" />
            <BannerContent>
                <Typography variant="h6">Huge Collections</Typography>
                <BannerTitle variant="h2">
                    Brand Bags
                </BannerTitle>

                <BannerDecs variant="subtitle">
                    Women all over the world love. You get the idea! It is more like a friend to them; to be with them all day and carry all the things that they need while making them look good. It has been found than on average, a woman has six handbags with her (not at the same time, obviously!)

                </BannerDecs>
            </BannerContent>
        </BannerContainer>
    )
}

export default Banner