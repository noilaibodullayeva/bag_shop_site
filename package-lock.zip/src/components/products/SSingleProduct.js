import { Product, ProductImage } from "../../styles/products";
import {PProductMeta} from "./PProductMeta";

const SSingleProduct = ({product, matches}) => {
    return(
        <Product>
            <ProductImage src={product.image}/>
            <PProductMeta product={product} matches={matches} />
        </Product>
    )
}

export default SSingleProduct;